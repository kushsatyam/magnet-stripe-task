require('dotenv').config();
const stripe = require('stripe')(process.env.SECRET_KEY);
const Orders = require('../model/order');


const makeOrders = async(req,res)=>{
    const {amount,currency,email,productIds} = req.body;

    // console.log(amount,currency);
    try {
    // const paymentIntent = await stripe.paymentIntents.create({
    //   amount,
    //   currency,
    // });

    const data = await Orders.create({email,productIds:JSON.stringify(productIds)});
    // console.log(data);

    res.send({...req.body,orderId:data.id});
  } catch (err) {
    console.log(err);
    res.status(500).send({ error: err.message });
  }
};

const makePayment = async(req,res)=>{
    const {amount,currency} = req.body;

    // console.log(amount,currency);

    const amountInCents = Math.round(amount * 100);
    try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount:amountInCents,
      currency,
    });

    res.send({
      clientSecret: paymentIntent.client_secret,
    });
  } catch (err) {
    console.log(err);
    res.status(500).send({ error: err.message });
  }
}


const confirmPaymentStatus = async (req,res)=>{
    try {
        const {orderId,transactionId,paymentStatus} = req.body;

        // console.log('order info ',req.body);
        const orderDetail = await Orders.findOne({where:{id:orderId}});

        if(!orderDetail){
            return res.status(400).send({msg:'Order Not Found'});
        }

        if(orderDetail.transactionId){
            return res.status(400).send({msg:'Order Status Already Changed'});
        }

        orderDetail.transactionId = transactionId;
        orderDetail.paymentStatus = paymentStatus;

        await orderDetail.save();

        return res.status(200).send({msg:'Order Status Updated Successfully'});

    } catch (error) {
        res.status(500).send({error:err.message});
    }
}


module.exports = {makeOrders,makePayment,confirmPaymentStatus};