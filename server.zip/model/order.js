const {DataTypes} = require("sequelize");
const sequelize = require("../config/db");

const Orders = sequelize.define('order',{
    id:{
        type:DataTypes.INTEGER,
        primaryKey:true,
        autoIncrement:true,
    },
    transactionId:{
        type:DataTypes.INTEGER,
        allowNull:true,
    },
    email:{
        type:DataTypes.STRING,
        allowNull:false,
    },
    paymentStatus:{
        type:DataTypes.BOOLEAN,
        defaultValue:false,
    },
    productIds:{
        type:DataTypes.STRING,
        allowNull:false,
    }
})

module.exports = Orders;