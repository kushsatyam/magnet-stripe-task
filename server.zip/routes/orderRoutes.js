const router = require('express').Router();

const {makeOrders,makePayment,confirmPaymentStatus} = require("../controller/order");

router.post('/makeOrders',makeOrders);
router.post('/makePayment',makePayment);
router.post('/confirmPayment',confirmPaymentStatus);

module.exports = router;