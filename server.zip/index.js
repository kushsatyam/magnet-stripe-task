const express = require("express");
const app = express();
const cors = require("cors");
const sequelize = require("./config/db");
const orderRoutes = require("./routes/orderRoutes");
require('dotenv').config();


app.use(cors({origin:'*'}));
app.use(express.json());

app.use("/order",orderRoutes);

const connectDb = async ()=>{
    try {
        await sequelize.authenticate();
        await sequelize.sync();

        console.log('Db Connected Successfully');
    } catch (error) {
        console.log(error);
    }
}

connectDb();

app.listen(5000,()=>{
    console.log("Server is listening on port 5000");
})