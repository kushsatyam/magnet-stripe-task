const {Sequelize, ConnectionTimedOutError} = require('sequelize');

const sequelize = new Sequelize('stripeorder','root','',{
    host:'localhost',
    port:3306,
    dialect:'mysql',
    dialectOptions:{
        connectTimeout:60000
    }
});


module.exports = sequelize;
