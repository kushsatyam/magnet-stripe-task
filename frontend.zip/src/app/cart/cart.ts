import { Component, inject, OnInit } from '@angular/core';
import { Product } from '../services/product';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-cart',
  imports: [NgFor,NgIf,RouterLink,CommonModule,FormsModule],
  templateUrl: './cart.html',
  styleUrl: './cart.css'
})
export class Cart implements OnInit{

  productService = inject(Product);
  productList:any=[];
  productCartIds:any=[];

  cartData :any={
    email:'',
    productIds:[],
    amount:0,
    currency:'usd'
  }

  constructor(private router:Router){}

  ngOnInit(): void {
    let ids = localStorage.getItem('productcartids');
    if(ids){
      this.productCartIds = JSON.parse(ids);
    }
    this.getProductList();
  }

  getProductList(){
    this.productService.getProductList().subscribe({
      next:(res:any)=>{
        this.cartData.amount = 0;

        this.productList = res.body.products.filter((el:any)=> this.productCartIds.includes(el.id));
        console.log('resp',this.productList);

        for(let item of this.productList){
          if(this.productCartIds.includes(item.id)){
            item.addToCart = true;
            this.cartData.amount += item.price;
          }
        }
      },
      error:(err)=>{
        console.log(err);
      }
    })
  }

  addToCart(item:any){
    console.log(item);

    if(this.productCartIds.includes(item.id)){
      this.productCartIds = this.productCartIds.filter((el:any)=> el!=item.id);
    }else{
      this.productCartIds.push(item.id);
    }
    console.log(this.productCartIds);

    localStorage.setItem('productcartids',JSON.stringify(this.productCartIds));

    this.getProductList();
  }

  

  proceedToCheckout(e:any){
    e.preventDefault();
    console.log('fire');
    if(this.cartData.email==''){
      return;
    }

    this.cartData.productIds = this.productCartIds;

    console.log(this.cartData)

    this.productService.makeOrder(this.cartData).subscribe({
      next:(res:any)=>{
        console.log(res.body);
        this.router.navigate(['/payment'],{state:{myData:res.body}})
//         this.router.navigate(['/payment'], {
//   state: { myData: { name: 'John', age: 30 } }
// });
      },
      error:(err)=>{
        console.log(err);
      }
    })
  }

}
