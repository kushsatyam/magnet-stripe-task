import { NgIf } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { loadStripe, Stripe, StripeCardElement } from '@stripe/stripe-js';

@Component({
  selector: 'app-payment',
  imports: [NgIf],
  templateUrl: './payment.html',
  styleUrl: './payment.css'
})
export class Payment implements OnInit{
  stripe!: Stripe | null;
  card!: StripeCardElement;
  cardErrors: string | null = null;

  paymentData:any={
    amount:'',
    currency:'',
  }

  paymentConfirmData:any={
    orderId:'',
    transactionId:'',
    paymentStatus:'',
  }

  constructor(private http: HttpClient,private router:Router) {
    const nav = this.router.getCurrentNavigation();
  const data = nav?.extras.state?.['myData'];
    this.paymentData = data
    this.paymentConfirmData.orderId = data.orderId;
  console.log('DataTransfer1',this.paymentData);
  }

  async ngOnInit() {

   

    this.stripe = await loadStripe('pk_test_51Rd5Uk2fqKsQSurzogThkHxeY7YhIYBIsOKCnXkaGCHFL5vfEYGQMgEmw15YmxshhHhYK0TNNB4ZcXAbooLKAcle00pYrPvFsf'); // use your public key
    const elements = this.stripe!.elements();
    this.card = elements.create('card');
    this.card.mount('#card-element');
  }

  async pay() {
    // Get PaymentIntent client secret from backend
    const response: any = await this.http
      .post('http://localhost:5000/order/makePayment', this.paymentData)
      .toPromise();

    const result = await this.stripe!.confirmCardPayment(response.clientSecret, {
      payment_method: {
        card: this.card,
      },
    });

    if (result.error) {
      this.cardErrors = result.error.message || 'Payment failed.';
       this.paymentConfirmData.transactionId = 'Invalid Id';
      this.paymentConfirmData.paymentStatus = false;
      this.confirmPaymentStatus();
    } else if (result.paymentIntent.status === 'succeeded') {
      console.log(result);
      this.paymentConfirmData.transactionId = result.paymentIntent.id;
      this.paymentConfirmData.paymentStatus = true;
      this.confirmPaymentStatus();
      alert('Payment successful!');
    }
  } 



  confirmPaymentStatus(){
    this.http.post('http://localhost:5000/order/confirmPayment',this.paymentConfirmData,{observe:'response'}).subscribe({
      next:(res:any)=>{
        console.log(res);
        localStorage.removeItem('productcartids');
        this.router.navigate(['/thank-you'])

      },
      error:(err)=>{
        console.log(err);
      }
    })
  }

}
