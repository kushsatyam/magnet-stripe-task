import { Routes } from '@angular/router';
import { ProductListing } from './product-listing/product-listing';
import { Cart } from './cart/cart';
import { Payment } from './payment/payment';
import { Thankyou } from './thankyou/thankyou';

export const routes: Routes = [
    {path:'',component:ProductListing},
    {path:'cart',component:Cart},
    {path:'payment',component:Payment},
    {path:'thank-you',component:Thankyou},
];
