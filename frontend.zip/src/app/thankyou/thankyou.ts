import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-thankyou',
  imports: [RouterLink],
  templateUrl: './thankyou.html',
  styleUrl: './thankyou.css'
})
export class Thankyou {

}
