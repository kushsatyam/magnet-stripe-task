import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Product {

  constructor(private http:HttpClient) { }

  getProductList(){
    return this.http.get('https://dummyjson.com/products',{observe:'response'});
  }
  
  makeOrder(data:any){
    console.log(data);
    return this.http.post('http://localhost:5000/order/makeOrders',data,{observe:'response'});
  }
}
