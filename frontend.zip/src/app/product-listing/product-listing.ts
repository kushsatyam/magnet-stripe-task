import { Component, inject, OnInit } from '@angular/core';
import { Product } from '../services/product';
import { NgFor } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-product-listing',
  imports: [NgFor,RouterLink],
  templateUrl: './product-listing.html',
  styleUrl: './product-listing.css'
})
export class ProductListing implements OnInit{
  productService = inject(Product);
  productList:any=[];
  productCartIds:any=[];

  ngOnInit(): void {
    let ids = localStorage.getItem('productcartids');
    if(ids){
      this.productCartIds = JSON.parse(ids);
    }
    this.getProductList();
  }

  getProductList(){
    this.productService.getProductList().subscribe({
      next:(res:any)=>{
        console.log('resp',res.body);
        this.productList = res.body.products;

        for(let item of this.productList){
          if(this.productCartIds.includes(item.id)){
            item.addToCart = true;
          }else{
            item.addToCart = false;

          }
        }
      },
      error:(err)=>{
        console.log(err);
      }
    })
  }

  addToCart(item:any){
    console.log(item);
    if(this.productCartIds.includes(item.id)){
      this.productCartIds = this.productCartIds.filter((el:any)=> el!=item.id);
    }else{
      this.productCartIds.push(item.id);
    }
    console.log(this.productCartIds);

    localStorage.setItem('productcartids',JSON.stringify(this.productCartIds));

    this.getProductList();
  }
}
